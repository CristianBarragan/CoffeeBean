﻿using CoffeeBeanery.GraphQL.Core.Sql;

namespace Domain.Model;

public partial class CustomerCustomerEdge
{
    public Customer? InnerCustomer { get; set; }
    
    public Guid? InnerCustomerKey { get; set; }
    
    public Customer? OuterCustomer { get; set; }
    
    public Guid? OuterCustomerKey { get; set; }

    public Guid? CustomerCustomerRelationshipKey { get; set; }
    
    public CustomerCustomerRelationshipType? CustomerCustomerRelationshipType { get; set; }

    public GraphModel? GraphModel { get; set; }
}

public enum CustomerCustomerRelationshipType
{
    Family,
    Partner,
    Widow,
    Single,
    Divorced
}
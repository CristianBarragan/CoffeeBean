using System;
using System.Collections.Generic;
using Microsoft.CodeAnalysis;

namespace CoffeeBeanery.GraphQL.Core.Mapping.Generators.Model
{
    public sealed class MappingClassInfo
    {
        public INamedTypeSymbol ClassSymbol { get; set; } = null!;

        // Graph/model type
        public INamedTypeSymbol ModelType { get; set; } = null!;

        // Primary Entity type for this mapping
        public INamedTypeSymbol? EntityType { get; set; }


        public string ClassName =>
            ClassSymbol.Name;


        public string Namespace =>
            ClassSymbol.ContainingNamespace?.IsGlobalNamespace == false
                ? ClassSymbol.ContainingNamespace.ToDisplayString()
                : "";


        public string Alias { get; set; } = "";

        public string Prefix { get; set; } = "";

        public string Schema { get; set; } = "";


        public bool IsModel { get; set; }

        public bool IsEntity { get; set; }

        public bool IsGraph { get; set; }



        public GraphInfo? Graph { get; set; }

        public MappingDefinitionInfo Definition { get; set; }



        /// <summary>
        /// Unique Entity symbols referenced by ModelToEntity.
        /// </summary>
        public List<INamedTypeSymbol> ModelToEntityTypes { get; }
            = new();



        public List<FieldInfo> FieldMaps { get; }
            = new();


        public List<FieldInfo> ManualFieldMaps { get; }
            = new();


        public List<ExcludedFieldMappingInfo> ExcludedFieldMappings { get; }
            = new();


        public List<ModelChildInfo> ModelChildren { get; }
            = new();


        public List<UpsertKeyInfo> UpsertKeys { get; }
            = new();


        public List<Diagnostic> Diagnostics { get; }
            = new();



        public List<AutoChildAttachmentInfo> AutoChildAttachments { get; }
            = new();



        public List<CteUpdateMetaInfo> CteUpdateMeta { get; }
            = new();



        public string Id { get; set; } = "";
    }



    public sealed class EntityKeyInfo
    {
        public string From { get; set; } = "";

        public string AliasFrom { get; set; } = "";


        public string? FromColumn { get; set; }


        public string To { get; set; } = "";

        public string AliasTo { get; set; } = "";


        public string? ToColumn { get; set; }


        // Entity type for this mapping entry
        public required INamedTypeSymbol EntityType { get; set; }


        // Model navigation alias:
        //
        // InnerCustomer
        // OuterCustomer
        //
        public string? AliasProperty { get; set; }


        public bool IsPrimary { get; set; }
    }



    public sealed class CteUpdateMetaInfo
    {
        public required string NavigationAlias { get; set; }

        public required string ForeignKeyColumn { get; set; }

        public required string OwningPrimaryKeyColumn { get; set; }

        public required string RelatedEntityTypeName { get; set; }

        public required string RelatedSurrogateIdColumn { get; set; }

        public required string RelatedNaturalKeyColumn { get; set; }
    }



    public sealed class AutoChildAttachmentInfo
    {
        public required string FieldName { get; set; }

        public required string ToModelName { get; set; }

        public required INamedTypeSymbol ParentEntityType { get; set; }

        public required string ParentJoinColumn { get; set; }

        public required INamedTypeSymbol ChildEntityType { get; set; }

        public required string ChildJoinColumn { get; set; }
    }



    public sealed class FieldInfo
    {
        public string SourceName { get; set; }

        public string DestinationEntity { get; set; }

        public string DestinationName { get; set; }

        public string? SourceAlias { get; set; }

        public string? DestinationAlias { get; set; }

        public Dictionary<string, int>? FromEnum { get; set; }

        public Dictionary<string, int>? ToEnum { get; set; }

        public Dictionary<string,string> EnumOverrides { get; } = [];

        public HashSet<string> EnumIgnore { get; } = [];
        
        public bool IsGenerated { get; set; }
    }



    public sealed class ExcludedFieldMappingInfo
    {
        public required string SourceName { get; set; }

        public required string DestinationEntity { get; set; }
    }



    public sealed class ModelChildInfo
    {
        public required string To { get; set; }
    }



    public sealed class UpsertKeyInfo
    {
        public required string Entity { get; set; }

        public required string Key { get; set; }
    }

    public sealed class GraphInfo
    {
        public string GraphName { get; set; }
        
        public string EdgeLabel { get; set; }
        
        public string EdgeKey { get; set; }
        
        public VertexInfo From { get; set; }
        
        public VertexInfo To { get; set; }
        
        public string FromJoinColumn { get; set; }
        
        public string ToJoinColumn { get; set; }
    }

    public sealed class VertexInfo
    {
        public string Label { get; set; } = string.Empty;

        public string KeyColumn { get; set; } = string.Empty;

        public string? Alias { get; set; }
    }

    public sealed class NavigationInfo
    {
        public required string NavigationName { get; set; }

        public required INamedTypeSymbol RelatedEntityType { get; set; }

        public required string ForeignKeyProperty { get; set; }

        public required string PrincipalKeyProperty { get; set; }

        public bool IsCollection { get; set; }

        public bool TargetIsRoot { get; set; }
    }



    public sealed class NavigationResolutionResult
    {
        public List<NavigationInfo> Navigations { get; }
            = new();


        public bool HasBlockingAmbiguity { get; set; }


        public List<Diagnostic> PendingDiagnostics { get; }
            = new();
    }
    
    public sealed record MappingDefinitionInfo
    {
        public INamedTypeSymbol ModelType { get; set; } = null!;

        public string? Schema { get; set; }

        public bool IsGraph { get; set; }

        public List<EntityDefinitionInfo> Entities { get; set; } = [];
    }
    
    public sealed record EntityDefinitionInfo
    {
        public INamedTypeSymbol EntityType { get; set; }

        public string FromColumn { get; set; } = string.Empty;

        public string ToColumn { get; set; } = string.Empty;

        public string To => EntityType.Name;

        public string? AliasProperty { get; set; }

        public bool IsPrimary { get; set; }
    }


    public sealed record FieldDefinitionInfo
    {
        public required string Source { get; set; }

        public required INamedTypeSymbol EntityType { get; set; }

        public required string Destination { get; set; }

        public EnumMappingDefinitionInfo? EnumMapping { get; set; }
    }


    // Non-generic base so FieldDefinition can reference it
    public abstract record EnumMappingDefinitionInfo
    {
        public abstract INamedTypeSymbol ModelEnum { get; }

        public abstract INamedTypeSymbol EntityEnum { get; }
    }


    // Strongly typed enum mapping
    // public sealed record EnumMappingDefinitionInfo<TModelEnum, TEntityEnum>
    //     : EnumMappingDefinitionInfo
    //     where TModelEnum : struct, Enum
    //     where TEntityEnum : struct, Enum
    // {
    //     public override INamedTypeSymbol ModelEnum => typeof(TModelEnum);
    //
    //     public override INamedTypeSymbol EntityEnum => typeof(TEntityEnum);
    //
    //
    //     /// <summary>
    //     /// Members where source and destination names differ.
    //     /// All other members are matched automatically by name.
    //     /// </summary>
    //     public Dictionary<string, string> Overrides { get; set; } = [];
    //
    //
    //     /// <summary>
    //     /// Members intentionally excluded from mapping.
    //     /// </summary>
    //     public HashSet<string> Ignore { get; set; } = [];
    // }


    public sealed record GraphDefinitionInfo
    {
        public required string GraphName { get; set; }

        public required string EdgeLabel { get; set; }

        public required string EdgeKey { get; set; }

        public required VertexDefinitionInfo From { get; set; }

        public required VertexDefinitionInfo To { get; set; }

        public required string FromJoinColumn { get; set; }

        public required string ToJoinColumn { get; set; }
    }


    public sealed class VertexDefinitionInfo
    {
        public required string Label { get; set; }

        public required string KeyColumn { get; set; }

        public string? Alias { get; set; }
    }
}